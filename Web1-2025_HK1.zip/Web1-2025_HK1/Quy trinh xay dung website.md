# Quy trình xây dựng website
## 1. Xác định và phân tích yêu cầu website - VD: website e-commerce
- Người dùng:
	+ Guest (Khách viếng thăm): k cần tài khoản đăng nhập vào hệ thống.
	+ Customer (khách hàng): có tài khoản đăng nhập để mua hàng.
	+ Admin (Nhân viên cửa hàng): là user có tài khoản có quyền thêm/xóa/sửa SP hoặc xem thống kê...
	+ Host: là user có khả năng cấu hình các thông tin liên quan đến website (kết nối CSDLM backup data, security...).
- Danh sách chức năng hỗ trợ:
	+ Guest: Xem sp, tìm kiếm sp, đăng ký tk...
	(Phải liệt kê tương ứng vs mỗi loại user).
- Thiết kế giao diện: hệ thống website có bao nhiêu trang web + liên kết giữa các trang.

=> Dựa vào yêu cầu khách hàng/ nhu cầu thực tế/ tham khảo các website tương tự.

## 2. Xây dựng giao diện web tĩnh
### 2.1 Phát thảo giao diện website
- Thường là sử dụng giấy & bút để vẽ ý tưởng.
	+ Xác định bố cục website.
	+ Xác định được phân bố các chức năng có trong website.

### 2.2 Thiết kế giao diện mockup/wireframe
- Sử dụng các công cụ hỗ trợ để vẽ layout (ở bước này chưa quan tâm đến màu sắc, hình ảnh, hiệu ứng).

### 2.3 Thiết kế đồ họa
- Thường là desinger xử lý.

### 2.4 Chuyển đổi thiết kế sang giao diện web thực tế
- Sử dụng các ngôn ngữ HTML, CSS, JS.
- HTML: định nghĩa cấu trúc nội dung của trang web: text, hình, bảng biểu...
- CSS: định nghĩa định dạng nội dung trang webL màu sắc, font, vị trí.
- JS: lập trình xử lý tương tác với người dùng: hiệu ứng, ktra nhập liệu...
=> Sử dụng công cụ VS Code

## 3. Thiết kế CSDL

## 4. Xây dựng ứng dụng web động

## 5. Triển khai
- Sử dụng Free Hosting có sẵn.

# Tổng quan thiết kế
## 1. Xác định kích thước khung nhìn:
- Mặc định: Width: **960px** (K thay đổi theo kích thước browser). Vì user thường sử dụng màn hình desktop: 1204x768 => Có thể mất khung => K nên chiếm hết màn hình.
- Hoặc Width: **90%**: thay đổi theo browser.

## 2. Xác định hệ thống menu
- Phải báo cho user biết họ đang ở đâu.

## 3. Dead-end
- Trang dead-end -> k có liên kết đến trang web khác.
- Mỗi trang có ít nhất 1 link, k được có link -> luôn luôn có link quay lại trang chủ (thường hay nằm ở logo).

## 4. Chức năng tìm kiếm
- Nên nằm bên góc phải trang web.

## 5. Tính nhất quán
- Mọi website đều đc thiết lập quanh Home page => Bố cục, menu, màu sắc... phải giống nhau để user biết vẫn đang ở cũng 1 website.

## 6. Tính tương thích
- K phải mọi browser đều hiển thị web giống nhau.
- Hoặc nhiều thiết bị
=> Phải thiết kế giao diện tương ứng

## 7. Xác định font chữ
- Nguyên tắc: tiếng việt (Unicode), không đc sử dụng VNI/TCVN3 vì k phổ biến trên thế giới.
- Thường là: Font sans-serif (website hiện địa chuộng) hoặc Serif (truyền thống, tin tức, kể chuyện).
- Google web font: nhúng font vào web thông qua link, có thể sử dụng bất kì font nào.
- Font size nội dung: 15-25px
- Font size lớn cho Headline.
- Line spacing: 120-150%.
- Nên 45-90 ký tự 1 dòng.

## 8. Màu sắc
- Color wheel: Hue, Tint, Tone, Shade.
- Đọc lại trong file để biết ý nghĩa các gam màu.
- Hoặc do sở thích khách hàng, người thiết kế. Tuy nhiên k nên sử dụng màu quá nổi (vd đỏ -> nhức mắt). K chọn màu đen là màu đen, nên chọn màu trắng.
- Phối màu đơn sắc: Chọn 1 màu -> Thay đổi radient -> bộ màu
- Chọn các màu tuần tự.
- Chọn màu tương phản.
- Tool: color schema generator
- Nên sử dụng web pallete (màu chuẩn).

## 9. Hình ảnh
- nhiều loại: gif, png, jpeg
- Transparent: độ trong suốt
- Interlacing: lần lượt hiển thị từng dòng/lớp/điểm màu trên hình, kích thước file lớn => Cảm giác thấy hình nhanh
- Gif: ảnh động, có T và I, thích hợp vs hình màu sắc đơn => Logo.
- PNG: ảnh đẹp nhất, nhưng size lớn.
- JPEG: chất lượng thấp, size nhỏ, thích hợp vs các ảnh phức tạp.
=> JPEG là đủ.

## 10. Thủ thuật
- Để chữ trên hình
- Để chữ trong box
- Che phủ hình
- Dùng icon chi Features/Steps; Action/Link. 