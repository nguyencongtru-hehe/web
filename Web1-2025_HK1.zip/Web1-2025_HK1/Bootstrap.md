# Class Bootstrap
# Layout Bootstrap - kích thước web thay đổi tùy theo thiết bị
- Sử dụng % cho width.
- Cần thêm các dòng meta như sau:
```
<meta http-equiv="X-UA-Compatible" content="IE-edge">

```