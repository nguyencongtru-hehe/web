# CSS box model
- vùng chứa nội dung trong HTML. Chứa các thuộc tính:
	+ Margin: khoảng cách đường viền từ thẻ này tới thẻ khác
	+ Border: đường viền
	+ PaddingL khoảng cách từ border tới nội dung
	+ Element width: chiều dài của content
	+ Containing Block Width: chiều dài của tất cả cái ở trên.

# CSS Layout - display
- Chỉ định cách thức hiển thị của nội dung.
- `display: block | inline | none | inline-block`

- `display: none`: ẩn một phần tử
- `visibility: hidden`: ẩn 1 ptu nhưng vẫn chiếm k gian, có 1 vùng trống.

- `margin: auto`: tự động canh vùng nội dung ở giữa đối tượng chứa nó.
```
#box1{
	width: 100px;
	margin: 0 auto;
}
```

- max-width và min-height: thiết lập vùng rộng tối đa hoặc chiều cao tối thiểu của vùng nội dung.

- position: chỉ định vùng hiển thị của vùng nội dung
	+ static: gtri mặc định  ảnh hưởng top, bottom, left, right
	+ fixed: cố định vtri browser, k thay đổi vị trí khi kéo thanh trượt của browser
	+ relative: thay đổi theo vị trí mặc định của nó và chiếm chỗ (k cho box khác chiếm chỗ cũ)
	+ absolute: thay dổi theo vị trí so với thẻ cha của nó, trả chỗ cũ cho box khác
- fixed: quảng cáo; relative, absolute tùy mục đích

- `float: left | right`: căn lề trái, phải của box.
- `clear: both;`: tắt float trái/phải

- `overflow:auto`


```
<div id="wrapper">
	<div id="logo">Logo</div>
	<div id="navigation">Navigation</div>
	<div id="banner">Banner</div>
	<div id="logo">Logo</div>
	<div id="logo">Logo</div>
	<div id="logo">Logo</div>
</div>
```