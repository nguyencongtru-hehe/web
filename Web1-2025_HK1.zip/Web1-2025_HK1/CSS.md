# CSS
## 1. Phân loại CSS
- Inline Style Sheet: nhúng CSS vào tag HTML, chỉ có tác dụng trên thẻ đó.
	+ Syntax: `<tag style="attribute:value;">`

- Internal Style Sheet (Embedded): nhúng CSS vào trang web, chỉ có tác dụng trên 1 trang HTML (page)
	+ Syntax: `<head><style type="text/css">...</style></head>`

- Linking style sheet (external): có tác dụng trên nhiều tag, nhiều page, dùng nhiều nhất.
	+ `<head><link rel="stylesheet" href="url"></head>`

- `<style type="text/css" media="all | print | screen">`


## 2. Selector
- Universal: * (tất cả các thẻ)
- Element: h1 (tất cả thẻ h1)
- Id: #mauDo. Nên sài cho 1 thẻ duy nhất
- Class: .mauXanh, nhóm nhiều thẻ với nhau
- Element.class: li.mauTim (dòng li nào có class là mauTim)
- Element .class: li .mauTim (thẻ con nào màu tím trong thẻ li)
- Contextual: div span (thẻ span lồng trong thẻ div)
- Grouping: div, span (gom nhóm div và span)
- a:hover (cho chuột)
- p::first-letter (ký tự đầu tiên thẻ p)
- div > span: thẻ span có thẻ cha là div
- div + span: thẻ span có thể đứng trước là div
- a[attr]: thẻ a có thuộc tính là attr
- a[attr=value]: thẻ a có thuộc tính attr có gtri value

## 3. Độ ưu tiên
- Inline: cao nhất
- Internal & import
- Linking style sheet
- Browser default

- Trong trường hợp nhiều selector cùng trỏ vào 1 vùng: ABCD
	+ A = style
	+ B = ID(#)
	+ C = class(.), attribute `[]`, pseudo class `:`.
	+ D = element & pseudo element `::`.
- VD: style.css
```
article a span{
	color: blue;
}
=> 0003
#red{
	color:red;
}
0100
```

- Nếu có cùng độ ưu tiên => browser lấy cái cuối cùng (overwrite).

- Khi k biết chắc độ ưu tiên trong framework, thì dùng `!important` bên cạnh thuộc tính => xem nó la độ ưu tiên cao nhất

## 3. Một số thao tác
- Ví dụ mã màu quá khó nhớ nhưng cần thao tác ở nhiều vị trí khác nhau. Ứng dụng cho các phần khác.
```
<head>
	<style>
		:root{
			--mau-xanh-la: #009900;
		}
		h3{
			color: var(--mau-xanh-la)
		}
	</style>
</head>
```

## 4. Relative lengths
- em: kích thước dựa trên gtri tương đối của thành phần element => có khả năng kích thước bị tăng khi dùng thẻ lồng thẻ.
- rem: lấy kích thước ở root, đc quy định trong html
`<style> html{font-size: 2rem} </style>`

## 5. Font family
- Sans-serif: k chân
- Serif: Có chân
- Monosapce: code
- Cursive: viết tay
- Fantasy: trang trí
- Trong font-family có thể quy định, kết hợp nhiều loại font. Tên font có khoảng trắng, cần nháy đôi.
- Font được nhúng sẵn trên Internet `fonts.google.com` -> tìm font mình muốn -> Get font -> Embent code -> cung cấp code để copy, ghi vào code của mình.

## 6. Icons
- Dùng định dạng vector.
- Dùng Font Awesome -> cung cấp link -> nhúng link vào trang web.

## 7. Link
- Giúp thay đổi màu sắc dựa vào trạng thái link
- a:link: bình thường, chưa thăm
- a:visited: đã ghé thăm
- a:hover: mouse over link
- a:active: click mà chưa nhả con chuột ra
- Nếu dùng 4 trạng thái, thứ tự: a:hover trước a:ink, a:visited; a:active trước a:hover

## 8. Icon list
- `list-style-type`
- `list-style-image`: thay đổi thành hình ảnh

## 9. Background
- `background-color`
- `background-image`: opacity: độ trong suốt, hoặc dùng rbga (a đại diện cho độ trong suốt).
- Hình nhỏ -> browser sẽ lặp hình. Có thể đặt `background-repeat: no-repeat` để k lặp.
- Quy định hình nằm đâu: `background-position`
- `back-ground: fixed`: vùng hiển thị thay đổi k đổi background