# Form
- Bắt buộc nhập liệu: sử dụng thuộc tính `required` (bắt buộc phải nhập và khác rỗng).
```
<input type="text" name="fname" required>
```
- Thuộc tính `type`: kiểu dữ liệu nhập vào.
- Pattern: các kí tự được nhập

## 1. Email
- Với required trong email: nó kiểm tra rất đơn giản: `abs@.s` (có @ và dấu .). Nên có thêm `pattern="[a-z0-9._%+-]+@+[a-z0-9.-]+\.[a-z]{2,3}$"` dùng regex, các ký tự có thể xuất hiện nhiều lần + @.

## 2. Các loại input pattern
- Đọc thêm tài liệu cô gửi

# Định dạng valid/invalid input sử dụng CSS
```
<style>
	input:required:invalid, input:focus:invalid {
		background-image: url(images/invalid.png);
		background-position: right top;
		background-repeat: no-repeat;
	}

	input:required:valid, input:focus:valid{
		background-image: url(images/valid.png);
		background-position: right top;
		background-repeat: no-repeat;
	}
</style>
```

# Password
- Đổi password thành text: tính năng show password
```
<scipt>
	function showPass(checked){
		if (checked){
			document.querySelectorAll('input[type=password]').forEach(item => item.type = 'text');
		}
		else{
			document.querySelectorAll('input[type=text]').forEach(item => item.type = 'password');
		}
	}
	document.querySelector('#showPassword').onlick = e => showPass(e.target.checked);
</script>
```
- kiểm tra Pass có giống nhau k trong chức năng change password.
```
<form action="xuly.html" method="post">
	<fieldset>
		<div>
			<label for="oldPassword">Old Password</label>
			<input type="text" name="oldPassword" id="oldPassword" required="">
		</div>

		<div>
			<label for="confirmPassword">Confirm Password</label>
			<input type="text" name="confirmPassword" id="confirmPassword" required="">
		</div>

		<div>
			<input type="submit" value="Update">
		</div>
		new
	</fieldset>
</form>

<script>
	//Hàm k tên, gọi thực thi luônn
	(function(){
		var newPassword = document.getElementById("newPassword");

	})();
</script>
```
