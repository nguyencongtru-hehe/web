# HTML DOM 
- HTML elements: objects
- property là giá trị bạn có thể get hoặc set (nội dung của 1 thẻ HTML).
- method: hành động

## 1. Finding HTML elements
- document.getElementById(id): tìm element qua id.
- document.getElementByTagName(name): tìm element qua tag name
- document.getElementByClassName(name): tìm element qua class name.

## 2. Changing HTML elements
- Property:
	+ *element*.innerHTML: thay đổi nội dung bên trong 1 thẻ HTML.
	+ *element*.attribute: thay đổi gtri attribute của 1 thẻ HTML (ví dụ href trong tag <a>).
	+ *element*.style.property: đổi style.
- Method:
	+ *element*.setAttribute(attribute, value): thay đổi gtri attribute của 1 thẻ HTML (ví dụ href trong tag <a>).

## 3. Thêm và xóa element
- document.createElement(element): tạo mới.
- document.removeChild(element): xóa
- document.appendChild(element): thêm (add)
- document.replaceChild(new, old): thay thế
- document.write(text): viết vô HTML output stream

## 4. Thêm xử lý sự kiện
- document.getElementById(id).onclick = function(){code}: thêm code xử lý sự kiện cho event onclick.
