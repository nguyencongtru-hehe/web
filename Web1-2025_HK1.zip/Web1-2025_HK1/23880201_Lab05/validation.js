//dinh nghia func, roi thuc thi no ngay lap tuc
(function () {
    var pass1 = document.getElementById("newPass");
    var pass2 = document.getElementById("confi");

    var checkPass = function () {
        if (pass1.value != pass2.value){
            pass2.setCustomValidity('Passwords must match.');
        }
        else{
            pass2.setCustomValidity("");
        }
    };

    pass1.onchange = checkPass;
    pass2.onchange = checkPass;
}());