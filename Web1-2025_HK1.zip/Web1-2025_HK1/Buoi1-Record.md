# Lập trình web 1 - Record buổi học
## Buổi 2
- Website là 1 tập hợp nhiều trang web có liên kết với nhau => Đc lưu trữ trong 1 thư mục duy nhất.
- Host: Web server
- Cần cài thêm extension Live Server để có giả lập web server trên máy tính, chứ double click nó giống mở file hơn 1 website
- Tên file (web tĩnh):
	+ extension: .htm và .html
	+ Mặc định trang chủ website: index.html (k phải .htm). Cách duy nhất để thay đổi trang chủ là phải cấu hình trong web server. 
- Khi file html chưa chuẩn hóa, website tự chuẩn hóa (tự thêm các tag) để nó "hiểu" đc => Làm sai sẽ bị thay đổi bố cục trang web mong muốn.
- Cú pháp: thiếu <!doctype html> nó sẽ hiển thị version cũ.
- Phân biệt <div> và <p> (định dạng đoạn văn bản, nên k lồng nhau đc).
- List: ul (k thứ tự) và ol (có thứ tự).
- Ảnh: <img src="" alt="">
- Nên để thẻ <i> ngoài <a>: Mục đích <i> là hiển thị icon
- Điều hướng (navigation) hiển thị danh sách kiểu hyperlink: dùng tag <nav>
- Kẻ bảng: kẻ dòng trước rồi mới căn ô.
- Phân vùng (layout): dùng thẻ ngữ nghĩa như header, footer