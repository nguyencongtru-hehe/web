# JavaScript
## 1. Tổng quan
- Ngôn ngữ thông dịch (trình chạy nó tự dịch => k biên dịch qua ngôn ngữ trung gian).
- Dùng để xử lý các tương tác trên trang web => smart house.
- Thay đổi HTML, thay attribute trong HTML, thay đổi CSS.

## 2. Nhúng JavaScript 
- Khi nhúng trực tiếp `<script>` vào trang web, trong thẻ head thì nó load từ đầu => Load trước. Thông thường thẻ script nào sài lại phía trên thì hay chèn cuối thẻ body => K bị mất data.
- Hoặc chèn lệnh trong script luôn.
- Khi sài `<script src=''>` thì k để các lệnh trong thẻ script nữa, vì nó sẽ k gọi.

## 3. Data Type
- Numbers
- String
- Array
- Object
- Syntax: `var number1 = <data>`, tự nhận kiểu của biến theo gtri được gán. VD: 3-> numbers; "abc" => string.

## 4. Name Convention
- Cách đặt tên biến (Name Convention) chứa: kí tự, số, underscore _ và dấu $.
- Bắt đầu: letters, _, $
- Case sensitive
- Đặt tên theo 
	+ Camel Case (myFavColor), 
	+ Partial Case (MyFavCase), 
	+ Underscore Case (my_fav_color).

## 5. Function
- Syntax `function <tenHam>(){}`
- Ví dụ:
```
<script>
	var num1 = 1;
	var num2 = 2;
	function sum(x, y){
		return x + y;
	}
	sum(num1, num2);
</script>
```

## 6. Arrays
- Syntax: `var colors = ['red', 'green', 'blue'];`
- Truy xuất gtri cụ thể: `colors[0]`. Chỉ số mảng bắt đầu từ 0.

- Kiểu khác: 
```
var numbers = new Array();
number[0] = 1;
number[1] = 5;
numbers.push(4); //khỏi phải nhớ chỉ số, luôn chèn cuối
```

- `numbers.length`: xem số ptu mảng.
- `numbers.sort()`: sort theo tăng/giảm dần.
- `numbers.reverse()`: đảo mảng.

## 7. Loops: for, while, foreach
```
for(var i=0; i < colors.length; i++){
	console.log(colors[i]);
}
```
```
var i = 0;
while(i < colors.length){
	console.log(colors[i]);
	i++;
}
```
```
colors.forEach(function(color){
	console.log(color);
});
```

## 8. Điều kiện: if, if else, switch
- === Kiểm tra cùng gtri và cùng kiểu dữ liệu
```
var var1 = 3;
if(var1 == 3){
	cosole.log('this is true')
}
else{
	console.log('this is false')
}
```
```
var animal = 'dog';
swithch(animal){
	case 'dog':
		console.log('true');
		break
	case 'cat':
		console.log('fasle');
		break;
	default:
		console.log('i like rabbit');
}
```

## 9. Object
```
var person{
	firstName: 'John';
	lastName: 'Lin';
	age: 30;
	fullName: function(){
		return firstName + ' ' + lastName;
	}
};
console.log(person.fullName());
console.log(person.age);
```
```
//Object constructor
var cat = new Object();
cat.color = 'black';
cat.says = function{
	return 'A cat say mew';
}
```
- Cải tiến hơn
```
var animal = function(name, color){
	this.name = name;
	this.color = color;
}
var cat = new animal('cat', 'black');
```

## 10. Events
- Nhw onlock, onmouseover...
- Có thể chèn lệnh JS trong tag `<script>` trong Head hoặc link với file ngoài.
```
<script>
	//khai báo biến
	var x; //underfined
	var y=5; //number
	z = 6; //global

	var myName = 'ttramAnh';
	console.log(myName);

	function myFunc(){
		var x = 2;
		console.log(x);
	}

	myFunc(); //2
	console.log(x); //underfined
</script>
```	

# Các cú pháp mới trong JS
## 11. Arrow function
`let inc = x => x+1`
```
let inc = (x,y) => {
	console.log(x+y);
	return x + y;
}
```

## 12. Thời gian đồng hồ
- setTimer(), setInterval() 
- `setInterval(inc(1,3), 1000);` gọi 1 hàm khác sau 1 khoảng thời gian.
```
function myTimer{
	var d = new Date();
	var t = d.tolocaleTimeString();
	document.getElementById('header').innerText - t;
}
<script>
	setInterval(myTimer, 1000);
</script>
```

## 13. Khai báo
```
var x = 1 //global
y = 2; //global nhưng k nên
let z = 3; //block scope
const C = 5; //block scope
```

# DOM
- Có thể chèn JS trực tiếp trong thẻ HTML, ví dụ:
`<button onclick="alert(1)>` hoặc `<button onclick="showAlert()">`
- Cách khác:
```
<script>
	//Cách 1
	let button = document.querySelector('#myButton');
	button.onclick = showAlert; //gán thuộc tính onclick của cái nút bằng hàm muốn xử lý

	//Cách 1.1
	let button = document.querySelector('#myButton');
	button.onclick = function(){
		alert('MSSV-Ho ten');
	};


	//Cách 2
	function showAlert(){
		alrt('MSSV-Ho ten');
	}

	//Cách 3: 
	button.addEventListener('click', showAlert); //lắng nghe sự kiện click, có sự kiện xảy ra sài hàm showAlert
</script>
```
- `prompt`:  hiện cửa sổ giống alert nhưng có ô textbox để người dùng nhập vào.
- confirm là cửa sổ xác nhận, vd có muốn xóa k?
```
function showAlert(){
	//let input = prompt('Hello');
	let input = confirm('Do you really want to do this?');
	//cancel = fasle, ok = true
	document.querySelector('#message').innerHTML = input;
}
```
- innerText: nhập gì đó thì nó hiển thị (tag HTML cũng xem như là text).
- Còn innerHTML: cho phép nội dung hiển thị như 1 HTML.
- Thông thường các cửa sổ là tùy vào browser, nhưng có thể định dạng lại bằng HTML/CSS.

## 1. Active icon
- `<img src="a.png" onmouseover="this.source='b.png'" onmouseout="this.source='a.png'">`: nhưng nó sẽ xanh hoài luôn => bắt con chuột đi ra nữa.

## 2. Xử lý nhiều active icon
```
<script>
	// B1: lấy ra danh sách tất cả các thẻ img
	document.querySelectorAll('img').forEarch(item =>
		let imagePath = item.src;
		let activeImagePath = imgPath.replace('png', '-active.png'); //đổi đường dẫn vì cái tên nó giống nhau, kiểu thế
		//khi mà
		item.onmouseover = () => {
			item.src = activeImagePath;
		}
		//khi mà
		item.onmouseout = () => {
			item.src = imagePath; 
		}
		)
</script>
```

## 3. Check/Uncheck All
```
<script>
	function check(checked = true){
		document.querySelectorAll('input[type="checkbox"]').forEach(item =>{
			item.checked = checked;
			})
	}
</script>
```

## 4. Filter
```
<script>
	function filter(keyword){
		document.querySelectorAll('.list-group-item:not('.list-group-item-action)').forEach(item => {
			if(item.innerText.index0f(keyword) >= 0 {
				item.style.display = 'block';
				})
			})
	}
</script>
```

## 5. Add item
```
<script>
	function addItem(e){
		//ngăn k cho form submit
		e.preventDefault();

		let keyword = document.querySelector('#keyword');
		let text = keyword.value.trim();
		if(text){
			let ul = document.querySector('#myList');
			let li = document.createElement('li');
			li.innerText = text;
			li.className = 'list-group-item';
			ul.insertBefore(li, ul.firstElementChild);
			//reset keyword
			keyword.value = '';
		}
	}

	document.querySelector('form')
</script>
```