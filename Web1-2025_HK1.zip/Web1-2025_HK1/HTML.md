# 1. Cú pháp HTML
```
<!DOCTYPE html>
<html lang="en">
<head>
	<meta>
	<title></title>
	<link rel="shorcut icon" href="" type="image/x-icon"
</head>

<body>
	<h1 style="color:red">Tiêu đề</h1>
</body>
</html>
```
- `<meta>`: quy định thuộc tính
- `link`: icon cho trình duyệt.
- Có thể dùng extension để nó tự đóng tag.
- Bỏ qua kí tự khoảng trắng và xuống hàng. Để có thì dùng tag `<br>` cho xuống hàng; khoảng trắng là `&nbsp;`. Xem thêm danh sách các ký tự đặc biệt.
- ghi chú: <!-- -->

# 2. Các thẻ html
- Có 2 nhóm thẻ:
	+ Block Element: `<div> </div>`. Nội dung tự động xuống hàng.
	+ Inline Element: Nội dung không xuống hàng như `<em></em>`, `<b></b>`.

## 2.1 Một số thẻ HTML thông dụng:
- Heading `(h$*6)`: `<h1></h1>`cho tới `<h6></h6>`
- Paragraph: `<p></p>`.
- tag pre: Nội dung trong thẻ thế nào -> thể hiện ra ngoài y chang.
- Ảnh: `<img src="" alt="Koala">` => đường dẫn sai, alt thay hình.

- Thẻ hiển thị danh sách: Có 2 loại danh sách, có thể sử dụng lồng nhau. Nội dung trong danh sách dùng tag `<li>`. Thường dùng để định nghĩa hệ thống menu: 
	+ có thứ tự: `<ol type="I","A"...></ol>`
	+ K có thứ tự: `<ul type="round", "square"...></ul>`
	+ `<li><a href="">Home</a></li>`: menu


- Thẻ liên kết - hyperlink: `<a href="" target="_blank">Nội dung</a>`.
	+ Liên kết ngoài: liên kết đến 1 trang web nằm ngoài hệ thống website => `target="_blank"`.
	+ Liên kết nội: liên kết đến trang web nằm trong hệ thống web.
	+ Liên kết đến 1 vị trí cụ thể trong nội dung trang web: Sử dụng 2 cấp thẻ a `<a name="></a>` => đánh dấu vị trí, `<a href="#tenvitri">Nội dung</a>` => để tạo liên kết.
	+ Bên trong thẻ a có thể là 1 hình ảnh: `<a href=""><img src="" alt=""></a>`
	+ Muốn hiển thị 1 danh sách các hyperlink: bỏ các tag `<a>` vào:
		+ tag `<div class="nav">`: an toàn nhất để gom nhóm.
		+ tag `<nav>`: có ngữ nghĩa rõ ràng => biết chắc chắn đây là vùng navigation.
		+ tag `<ul>`: trong rất nhiều web dùng tag ul để gom nhóm và phân biệt các hyperlink.
	=> Nhiều nhất là nav và ul. Hoặc đặt `<ul>` vào `<nav>`.


- Kẻ bảng - table: 
	+ table: bắt đầu kẻ bảng.
	+ tr: dòng trong bảng; 
	+ td hoặc th (căn giữa): cột trong bảng.
	+ Nội dung 1 ô k có gtri thì dùng `&nbsp;`
	+ chiều dài của ô lớn hơn 1: `colspan=""`.
	+ chiều rộng của ô lớn hơn 1: `rowspan=""`
```
<table border="1">
	<tr>
		<td>1</td>
		<td>2</td>
	</tr>
</table>
```

## 2.2 Logo
- Nên dùng các ảnh vector thay cho ảnh thông thường => K bị bể, mờ hình.
`<i class="fa fa-html5" style="">`
- Cho phép user click vào logo => Quay về Home. Nhét hyperlink vào logo.
- Cách code logo chuẩn: click được cả vào chữ và logo.
```
<a href="#" style="">
	<i class="fa fa-html5"></i>HTML5</a>
```

# 3. Form
- Dùng tag form để định nghĩa, gồm 1 số thuộc tính:
	+ `name`: đặt tên form
	+ `action`: khi nhấn nút submit thì firm đc gửi đi đâu.
	+ `method`: GET (gtri gửi qua query string trong URL) hoặc POST (gtri gửi qua content trong request body -> dùng để gửi các ndung bảo mật. Bắt buộc sử dụng khi upload 1 file vì size lớn).
	+ `<form action="" method="POST" enctype="multipart/form-data">`: cho phép upload 1 file.
- Muốn gửi đc thì các input phải nằm trong form và phải có name (nếu không nó sẽ k gửi data đi). Form phải có action, k thì nó sẽ gửi lại chính trang web đó, cảm giác như load lại trang.
- Thẻ `<button>Submit</button>`: vẫn gửi data được lên server. Nếu form dùng button cũng thay thế cho input submit.
- Dùng `input type="button"` hoặc `button type="button"` => **K gửi được**. Dùng trong trường hợp muốn tự kiểm soát data => kết hợp với JS để lọc input.

```
<form name="" action="xuly.html" method="GET">
	<input type="submit" value="Submit"> //nút submit, browser gửi lên server
</form>
```

## 3.1 Text box: 
- id: định danh duy nhất.
- Nếu k có name thì data sẽ không được gửi qua URL
- Khi gắn thẻ label thì khi click vào Username -> nó nhảy vào ô textbox tương ứng.
- Phương thức mặc định khi không quy định là method GET.
- `placeholder="Enter your username"`: hiển thị để user biết nhập gì.
- Chỉ cho phép gửi data trên 1 dòng
```
<form action="xuly.html" method="POST">
	<div>
		<label for="username">Username:</label> <input type="textbox" name="username" id="username" placeholder="Enter your username">
	</div>
	<div>
		<label for="password">Password:</label> <input type="password" name="password" id="password">
	</div>
	<div>
		<input type="submit" name="Login">
	</div>
</form>

<form action="timkiem.html">
	<div>
		<label for="keyword">Keyword</label><input type="text" name="keyword" id="keyword">
	</div>
	<div>
		<input type="submit" value="Search">
	</div>
</form>
```

## 3.2 Checkbox
- Có thể chọn nhiều.
- Có thể thêm thuộc tính `checked` => mặc định nó được chọn.
```
<form action="">
	<div>
		<input type="checkbox" id="english"><label for="english">English</label>

		<input type="checkbox" id="vietnamese"><label for="english">Vietnamese</label>
	</div>
</form>
```

## 3.3 Radio Button
- Chỉ cho phép click 1 trong 2. Cần nhóm lại => Đặt chung 1 thuộc tính name.
- Có thể thêm thuộc tính `checked` => mặc định nó được chọn.
```
<form action="">
	<div>
		<input type="radio" id="english" name="language"><label for="english">English</label>

		<input type="radio" id="vietnamese" name="language"><label for="english">Vietnamese</label>
	</div>
</form>
```

## 3.4 Reset form
- Xóa toàn bộ nội dung user đã nhập => quay trở lại trạng thái ban đầu.
```
<div>
	<input type="reset" value="Reset">
</div>
```

## 3.5 Nút button thông thường
- User nhấp vào k có tác dụng gì => Sau này viết bằng JS để xử lý
```
<input type="button" value="My Button"
```

## 3.6 Thẻ textarea
- Cho phép gửi data nhiều dòng
```
<textarea name="message" id="" cols="30" rows="10"></textarea>
```

## 3.7 Combo box
- Chọn cái nào nó sẽ gửi đi gtri đó
- Hiển thị mặc định: `selected`.
- Có thể có nhiều `optgroup` và `option`
- Khi thêm `multiple="multiple"` vào select => Combo box thành list box, có thể chọn được nhiều lựa chọn.>
```
<select name="location" id="location">
	//gom nhóm
	<optgroup label="USA">
		<option value="ny">New York</option>
		<option value="tx">Texas</option>
	</optgroup>
	<option value="to" selected>Tokyo</option>
</select>
<input type="submit" name="Submit">
```

## 3.8 Fieldset - Grouping form data
- Giúp đóng khung vùng nhập liệu
```
<filedset>
	<ledend>Subject</legend> //tiêu đề
	<div>
		<input type="checkbox" name="subject" id="endlish"><label for"english">English</label>
	</div>

	<div>
		<input type="checkbox" name="subject" id="Web"><label for"web">Web</label>
	</div>
</fieldset>
```

# 4. Hyperlink
- Internal link: link trong nội bộ trang web.
	+ Đánh dấu chỗ muốn nhảy tới bằng id
	+ Trong hyperlink sài `#<id>`
```
<a href="#c4">Go to Chapter 4</a>
<h2 id="c4">Chapter 4</h2>
```
- External link: link tới trang web khác
- Email link: khi click máy sẽ tự động mở 1 cái mail client. Trong trường hợp máy k có mail client thì k mở.
`<a href="mailto:emailAdrress">Contact Admin</a>` => Giờ ít sài vì user k sài mail client nữa, mà sài mail server như gmail nhiều; hoặc mấy con bot cào mail để spam mail

# 5. Absolute URL
- Absolute URL: đchi tuyệt đối. URL đầy đủ: protocol + domain name + path directory (tới tài nguyên) + query string (gửi thông tin lên server) + fragment (tới internal link)
	+ Khuyết điểm: lỡ đổi tên thì link sẽ bị bể - broken link.

# 6. Relative URL
- Relative URL: đchi tương đối
- /: root dir của website
- ./: present file directory (theo mặc định)
- ../: quay về parent dir
- Ví dụ đi tới vị trí posB trong file A: `../../fileA.htm#posB`
